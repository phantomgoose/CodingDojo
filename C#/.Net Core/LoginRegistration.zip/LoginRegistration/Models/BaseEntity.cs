namespace LoginRegistration.Models {
    public abstract class BaseEntity {}
}